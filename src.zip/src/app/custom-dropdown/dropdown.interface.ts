export interface DropDownValue {
    title: string;
    subTitle?: string;
}